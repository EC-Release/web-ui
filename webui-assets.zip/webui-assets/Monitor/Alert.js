import React from "react";

export default class Alert extends React.Component {
    render() {
        return (
            <img className="img-fluid mx-auto d-block" src="assets/static/images/underconstruction.svg" alt="under_construction" />
        )
    }
}