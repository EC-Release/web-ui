import React from "react";

export default class Alert extends React.Component {
    render() {
        return (
            <div className="Alert">
                <img className="img-fluid mx-auto d-block" src="assets/static/images/underconstruction.svg" alt="under_construction" />
            </div>
        )
    }
}