import React from "react";
import ReactDOM from "react-dom";

export default class Report extends React.Component {
    render() {
        return (
            <img className="img-fluid mx-auto d-block" src="assets/static/images/underconstruction.svg" alt="under_construction" />
        )
    }
}