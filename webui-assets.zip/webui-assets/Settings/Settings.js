import React from "react";

export default class Settings extends React.Component {
    render() {
        /* jshint ignore:start */
        return (
            <img className="img-fluid mx-auto d-block" src="assets/static/images/underconstruction.svg" alt="under_construction" />
        )
        /* jshint ignore:end */
    }
}