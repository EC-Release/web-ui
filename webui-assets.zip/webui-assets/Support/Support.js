import React from "react";
import ReactDOM from "react-dom";

export default class Support extends React.Component {
    render() {
        /* jshint ignore:start */
        return (
            <img className="img-fluid mx-auto d-block" src="assets/static/images/underconstruction.svg" alt="under_construction" />
        )
        /* jshint ignore:end */
    }
}