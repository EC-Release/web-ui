import React from "react";

export default class Maintainwatchercreate extends React.Component {
    render() {
        /* jshint ignore:start */
        return (
            <h1 className="text-center">Maintain Watcher Create works!</h1>
        )
        /* jshint ignore:end */
    }
}