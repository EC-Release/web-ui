import React from "react";
import ReactDOM from "react-dom";

export default class Maintain extends React.Component {
    render() {
        return (
            <h1 className="text-center">Maintain works!</h1>
        )
    }
}