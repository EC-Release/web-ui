import React from "react";

export default class Maintain extends React.Component {

    constructor(props){
        /* istanbul ignore next */
        super(props);
    }

    /* istanbul ignore next */
    componentDidMount(){}

    render() {
        /* jshint ignore:start */
        /* istanbul ignore next */
        return (
            <h1 className="text-center">Maintain works!</h1>
        )
        /* jshint ignore:end */
    }
}