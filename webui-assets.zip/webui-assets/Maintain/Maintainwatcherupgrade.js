import React from "react";
import ReactDOM from "react-dom";

export default class Maintainwatcherupgrade extends React.Component {
    render() {
        return (
            <h1 className="text-center">Maintain Watcher Upgrade/Disable works!</h1>
        )
    }
}