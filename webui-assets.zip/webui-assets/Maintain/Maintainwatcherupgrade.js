import React from "react";

export default class Maintainwatcherupgrade extends React.Component {
    render() {
        /* jshint ignore:start */
        return (
            <h1 className="text-center">Maintain Watcher Upgrade/Disable works!</h1>
        )
        /* jshint ignore:end */
    }
}