import React from "react";

export default class Maintainwatcherview extends React.Component {
    render() {
        /* jshint ignore:start */
        return (
            <h1 className="text-center">Maintain Watcher View works!</h1>
        )
        /* jshint ignore:end */
    }
}