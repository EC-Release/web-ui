import React from "react";

export default class Dashboard extends React.Component {
    render() {
        /* jshint ignore:start */
        /* istanbul ignore next */
        return (
            <img className="img-fluid mx-auto d-block" src="assets/static/images/underconstruction.svg" alt="under_construction" />
        )
        /* jshint ignore:end */
    }
}