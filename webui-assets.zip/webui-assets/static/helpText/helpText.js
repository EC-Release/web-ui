export default 
{
    "mode" : "Agent mode",
    "environment": "Environment"
}